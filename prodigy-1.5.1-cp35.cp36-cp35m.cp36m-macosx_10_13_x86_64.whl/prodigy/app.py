# coding: utf8
from __future__ import unicode_literals

import hug
from hug_middleware_cors import CORSMiddleware
from pathlib import Path
import os

from . import about
from .util import prints, log


CONTROLLER = None
CONFIG = {}


def server(controller, config):
    """Serve the Prodigy REST API.

    controller (prodigy.core.Controller): The initialized controller.
    config (dict): Configuration settings, e.g. via a prodigy.json or recipe.
    """
    global CONTROLLER, CONFIG
    config['view_id'] = controller.view_id
    config['batch_size'] = controller.batch_size
    config['version'] = about.__version__
    instructions = config.get('instructions')
    if instructions:
        help_path = Path(instructions)
        if not help_path.is_file():
            prints("Can't read instructions", help_path, error=True, exits=1)
        with help_path.open('r', encoding='utf8') as f:
            config['instructions'] = f.read()
    for setting in ['db_settings', 'api_keys']:
        if setting in config:
            config.pop(setting)
    CONFIG = config
    CONTROLLER = controller

    from waitress.server import create_server
    api = hug.API(__name__)
    if config.get('cors', True) is not False:
        api.http.add_middleware(CORSMiddleware(api))
    port = os.getenv('PRODIGY_PORT', config.get('port', 8080))
    host = os.getenv('PRODIGY_HOST', config.get('host', 'localhost'))
    server = create_server(__hug_wsgi__, port=port, host=host,  # noqa: F821
                           channel_timeout=300, expose_tracebacks=True,
                           threads=1)
    prints('Starting the web server at http://{}:{} ...'.format(host, port),
           'Open the app in your browser and start annotating!')
    server.run()
    controller.save()


@hug.static('/')
def serve_static():
    # NB! This currently serves whole drive! Does nothing to prevent '../'
    return (str(Path(__file__).parent / 'static'),)


@hug.get('/project')
def get_project():
    """Get the meta data and configuration of the current project.

    RETURNS (dict): The configuration parameters and settings.
    """
    log("GET: /project", CONFIG)
    config = CONFIG
    return config


@hug.get('/get_questions')
def get_questions():
    """Get the next batch of tasks to annotate.

    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float}
    """
    log("GET: /get_questions")
    controller = CONTROLLER
    if controller.db and hasattr(controller.db, 'reconnect'):
        controller.db.reconnect()
    tasks = controller.get_questions()
    response = {'tasks': tasks, 'total': controller.total_annotated,
                'progress': controller.progress}
    log("RESPONSE: /get_questions ({} examples)".format(len(tasks)), response)
    if controller.db and hasattr(controller.db, 'close'):
        controller.db.close()
    return response


@hug.post('/give_answers')
def give_answers(answers=[]):
    """Receive annotated answers, e.g. from the web app.

    answers (list): A list of task dictionaries with an added `"answer"` key.
    RETURNS (dict): {'progress': float}
    """
    log("POST: /give_answers (received {})".format(len(answers)), answers)
    controller = CONTROLLER
    if controller.db and hasattr(controller.db, 'reconnect'):
        controller.db.reconnect()
    controller.receive_answers(answers)
    response = {'progress': controller.progress}
    log("RESPONSE: /give_answers", response)
    if controller.db and hasattr(controller.db, 'close'):
        controller.db.close()
    return response


if __name__ == '__main__':
    import plac
    plac.call(server)
